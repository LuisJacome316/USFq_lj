﻿using System.ComponentModel.DataAnnotations;

namespace Usfq_LJ.Entities
{
    public class Estudiante
    {
        public string Cedula { get; set; }
        [Required]
        public string Nombre { get; set; }
        public string Apellido { get; set; }
        public int Edad { get; set; }
       // public List<Curso> Cursos { get; set; }
    }
}
