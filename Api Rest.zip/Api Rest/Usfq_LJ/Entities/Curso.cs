﻿using System.ComponentModel.DataAnnotations;

namespace Usfq_LJ.Entities
{
    public class Curso
    {
        public int id_curso { get; set; }
       
        public string nombre_curso { get; set; }
        public string hora_inicio_curso { get; set; }
        public string hora_fin_curso { get; set; }
        public string numero_creditos_curso { get; set; }
       // public string Cedula { get; set; }
       // public Estudiante Estudiante { get; set; }
    }
}
