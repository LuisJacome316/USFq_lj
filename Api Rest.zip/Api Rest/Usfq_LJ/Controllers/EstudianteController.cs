﻿using Usfq_LJ.Context;
using Usfq_LJ.Entities;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Usfq_LJ.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EstudianteController : ControllerBase
    {
       private readonly ApplicationDBContext context;

        public EstudianteController(ApplicationDBContext context)
        {
            this.context = context;
        }

        [HttpGet]
        public ActionResult<IEnumerable<Estudiante>> Get()
        {
            //return context.Estudiante.Include(x => x.Cedula).ToList();
            return context.Estudiante.ToList();
        }

        [HttpGet("{cedula}", Name = "ObtenerEstudiante")]
        public ActionResult<Estudiante> Get(string cedula)
        {
            var estudiante = context.Estudiante.Include(x => x.Cedula).FirstOrDefault(x => x.Cedula == cedula);
            if (estudiante == null)
            {
                return NotFound();
            }
            return estudiante;
        }

        //[HttpPost]
        //public ActionResult Post([FromBody] Estudiante estudiante)
        //{
        //    context.Estudiante.Add(estudiante);
        //    context.SaveChanges();

        //    return new CreatedAtRouteResult("ObtenerEstudiante", new { id = estudiante.Cedula }, estudiante);
        //}

        //[HttpPut("{cedula}")]
        //public ActionResult Put([FromBody] Estudiante estudiante, string cedula)
        //{
        //    if (cedula != estudiante.Cedula)
        //    {
        //        return BadRequest();
        //    }

        //    context.Entry(estudiante).State = EntityState.Modified;
        //    context.SaveChanges();
        //    return Ok();
        //}

        //[HttpDelete("{cedula}")]
        //public ActionResult<Estudiante> Delete(string cedula)
        //{
        //    var estudiante = context.Estudiante.FirstOrDefault(x => x.Cedula == cedula);

        //    if (estudiante == null)
        //    {
        //        return NotFound();
        //    }
        //    //tambien puede usarse context.Autor.Remove(autor);
        //    context.Entry(estudiante).State = EntityState.Deleted;
        //    context.SaveChanges();
        //    return estudiante;
        //}
    }
}
